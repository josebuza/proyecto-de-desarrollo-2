import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ventanamenu extends JFrame implements ActionListener {



    public ventanamenu(){
        this.setLayout(null);
        this.setBounds(450,50,650,710);
        this.getContentPane().setBackground(new Color(172,181,189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);


        this.setTitle("menu");
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
