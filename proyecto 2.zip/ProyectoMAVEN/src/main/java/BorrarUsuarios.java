import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BorrarUsuarios extends JFrame implements ActionListener {
    private JTextField txtNombre;
    private JButton Bborrar, Bregresar;
    private TablaUsuarios tablaUsuarios;

    public BorrarUsuarios(TablaUsuarios tablaUsuarios) {
        this.tablaUsuarios = tablaUsuarios;

        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("BORRAR USUARIOS");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        JPanel regresar = new JPanel();
        regresar.setLayout(new GridLayout());
        regresar.setBounds(820, 335, 100, 60);
        regresar.setBorder(new LineBorder(Color.BLACK, 2));
        regresar.setBackground(new Color(172, 181, 189));
        this.add(regresar);

        Bregresar = new JButton("regresar");
        Bregresar.setForeground(Color.WHITE);
        Bregresar.setBackground(Color.DARK_GRAY);
        Bregresar.setBorder(new LineBorder(Color.BLACK, 4));
        Bregresar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        regresar.add(Bregresar);
        Bregresar.addActionListener(this);

        JLabel lblNombre = new JLabel("Nombre del Usuario");
        txtNombre = new JTextField(10);
        Bborrar = new JButton("Borrar");
        Bborrar.addActionListener(this);

        lblNombre.setBounds(20, 20, 100, 20);
        txtNombre.setBounds(120, 20, 200, 20);
        Bborrar.setBounds(820, 250, 100, 60);

        this.add(lblNombre);
        this.add(txtNombre);
        this.add(Bborrar);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";

        if (e.getSource() == Bborrar) {
            String Nombre = txtNombre.getText();

            try {
                Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
                String sql = "DELETE FROM usuarios WHERE nombre = ?";
                PreparedStatement preparedStatement = conexion.prepareStatement(sql);
                preparedStatement.setString(1, Nombre);
                int filasAfectadas = preparedStatement.executeUpdate();
                if (filasAfectadas > 0) {
                    JOptionPane.showMessageDialog(this, "Usuario Borrado Correctamente");
                    // Actualizar los datos de la tabla en la ventana TablaArticulos
                    tablaUsuarios.obtenerDatosTablaUsuarios();
                } else {
                    JOptionPane.showMessageDialog(this, "No se encontro el Articulo");
                }

                preparedStatement.close();
                conexion.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == Bregresar) {
            this.setVisible(false);
            tablaUsuarios.mostrarVentana();
        }
    }
}