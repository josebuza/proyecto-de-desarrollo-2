import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TablaArticulos extends JFrame implements ActionListener {
    InsertarArticulos insertarArticulos;
    BorrarArticulos borrarArticulos;

    private JTable tabla;

    JPanel Insertar, eliminar, regresar;
    JButton Binsertar, Beliminar, Bregresar;

    public TablaArticulos() {

        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("TABLA ARTICULOS");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Clave Articulos");
        modelo.addColumn("Nombre");
        modelo.addColumn("Precio");
        modelo.addColumn("Clave Fabricante");

        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";
        String consulta = "SELECT * FROM articulos";

        try {
            Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
            Statement statement = conexion.createStatement();
            ResultSet resultSet = statement.executeQuery(consulta);

            while (resultSet.next()) {
                String claveArticulo = resultSet.getString("clave_articulos");
                String nombre = resultSet.getString("nombre");
                String precio = resultSet.getString("precio");
                String claveFabricante = resultSet.getString("clave_fabricante");

                modelo.addRow(new Object[]{claveArticulo, nombre, precio, claveFabricante});
            }
            resultSet.close();
            statement.close();
            conexion.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        Container contentpane = getContentPane();
        contentpane.setLayout(null);
        tabla = new JTable(modelo);
        tabla.setBounds(50, 50, 400, 300);
        contentpane.add(tabla);


        JTableHeader header = tabla.getTableHeader();
        header.setBounds(50, 20, 400, 30);
        contentpane.add(header);

        Insertar = new JPanel();
        Insertar.setLayout(new GridLayout());
        Insertar.setBounds(820, 250, 100, 60);
        Insertar.setBorder(new LineBorder(Color.BLACK, 2));
        Insertar.setBackground(new Color(172, 181, 189));
        this.add(Insertar);

        Binsertar = new JButton("INSERTAR");
        Binsertar.setForeground(Color.WHITE);
        Binsertar.setBackground(Color.DARK_GRAY);
        Binsertar.setBorder(new LineBorder(Color.BLACK, 4));
        Binsertar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        Insertar.add(Binsertar);
        Binsertar.addActionListener(this);

        eliminar = new JPanel();
        eliminar.setLayout(new GridLayout());
        eliminar.setBounds(820, 165, 100, 60);
        eliminar.setBorder(new LineBorder(Color.BLACK, 2));
        eliminar.setBackground(new Color(172, 181, 189));
        this.add(eliminar);

        Beliminar = new JButton("ELIMINAR");
        Beliminar.setForeground(Color.WHITE);
        Beliminar.setBackground(Color.DARK_GRAY);
        Beliminar.setBorder(new LineBorder(Color.BLACK, 4));
        Beliminar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        eliminar.add(Beliminar);
        Beliminar.addActionListener(this);

        insertarArticulos = new InsertarArticulos();
        borrarArticulos = new BorrarArticulos(this);

        regresar = new JPanel();
        regresar.setLayout(new GridLayout());
        regresar.setBounds(820, 335, 100, 60);
        regresar.setBorder(new LineBorder(Color.BLACK, 2));
        regresar.setBackground(new Color(172, 181, 189));
        this.add(regresar);

        Bregresar = new JButton("REGRESAR");
        Bregresar.setForeground(Color.WHITE);
        Bregresar.setBackground(Color.DARK_GRAY);
        Bregresar.setBorder(new LineBorder(Color.BLACK, 4));
        Bregresar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        regresar.add(Bregresar);
        Bregresar.addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Binsertar) {
            insertarArticulos.setVisible(true);
            insertarArticulos.add(regresar);
            this.setVisible(false);
        }
        if (e.getSource() == Beliminar) {
            borrarArticulos.setVisible(true);
            borrarArticulos.add(regresar);
            this.setVisible(false);
        }
        if (e.getSource() == Bregresar) {
            if (insertarArticulos.isVisible()){
                insertarArticulos.setVisible(false);
            }

            if (borrarArticulos.isVisible()){
                borrarArticulos.setVisible(false);
            }
            this.setVisible(true);
            obtenerDatosTabla(); // Actualizar la tabla al regresar
        }

    }

    public void obtenerDatosTabla() {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);

        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";
        String consulta = "SELECT * FROM articulos";

        try {
            Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
            Statement statement = conexion.createStatement();
            ResultSet resultSet = statement.executeQuery(consulta);

            while (resultSet.next()) {
                String claveArticulo = resultSet.getString("clave_articulos");
                String nombre = resultSet.getString("nombre");
                String precio = resultSet.getString("precio");
                String claveFabricante = resultSet.getString("clave_fabricante");

                modelo.addRow(new Object[]{claveArticulo, nombre, precio, claveFabricante});
            }
            resultSet.close();
            statement.close();
            conexion.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void mostrarVentana() {
    }
}