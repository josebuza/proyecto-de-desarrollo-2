public class Main {
    public static void main(String[] args) {

        Interfaz menu = new Interfaz();
        menu.setVisible(true);



    }
}