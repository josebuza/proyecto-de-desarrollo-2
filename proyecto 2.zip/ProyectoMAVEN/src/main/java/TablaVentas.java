import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TablaVentas extends JFrame implements ActionListener {
private JTable tabla;

    JPanel Insertar,eliminar;
    JButton Binsertar,Beliminar;

    public TablaVentas(){

        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("TABLA VENTAS");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Articulo");
        modelo.addColumn("Vendidos");
        modelo.addColumn("Devueltos");

        String url="jdbc:mysql://localhost:3306/tienda";
        String usuario= "root";
        String contrasena="12345";
        String consulta="SELECT * FROM Ventas";

        try {
            Connection conexion= DriverManager.getConnection(url,usuario,contrasena);
            Statement statement = conexion.createStatement();
            ResultSet resultSet= statement.executeQuery(consulta);

            while (resultSet.next()){
                String Articulo= resultSet.getString("Producto");
                String Devueltos=resultSet.getString("Devueltos");
                String Vendidos= resultSet.getString("Vendidos");
                modelo.addRow(new Object[]{Articulo,Devueltos,Vendidos});
            }
            resultSet.close();
            statement.close();
            conexion.close();

        }catch (SQLException e){
            e.printStackTrace();
        }
        Container contentpane=getContentPane();
        contentpane.setLayout(null);
        tabla = new JTable(modelo);
        tabla.setBounds(50,50,400,300);
        add(tabla);


        JTableHeader header=tabla.getTableHeader();
        header.setBounds(50,20,400,30);
        contentpane.add(header);

        Insertar= new JPanel();
        Insertar.setLayout(new GridLayout());
        Insertar.setBounds(820, 250, 100, 60);
        Insertar.setBorder(new LineBorder(Color.BLACK,2));
        Insertar.setBackground(new Color(172,181,189));
        this.add(Insertar);

        Binsertar = new JButton("INSERTAR");
        Binsertar.setForeground(Color.WHITE);
        Binsertar.setBackground(Color.DARK_GRAY);
        Binsertar.setBorder(new LineBorder(Color.BLACK,4));
        Binsertar.setFont(new Font("Bauhaus 93",Font.BOLD,15));
        Insertar.add(Binsertar);
        Binsertar.addActionListener(this);
/*
        eliminar= new JPanel();
        eliminar.setLayout(new GridLayout());
        eliminar.setBounds(820, 165, 100, 60);
        eliminar.setBorder(new LineBorder(Color.BLACK,2));
        eliminar.setBackground(new Color(172,181,189));
        this.add(eliminar);

        Beliminar = new JButton("ELIMINAR");
        Beliminar.setForeground(Color.WHITE);
        Beliminar.setBackground(Color.DARK_GRAY);
        Beliminar.setBorder(new LineBorder(Color.BLACK,4));
        Beliminar.setFont(new Font("Bauhaus 93",Font.BOLD,15));
        eliminar.add(Beliminar);
        Beliminar.addActionListener(this);*/

    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}