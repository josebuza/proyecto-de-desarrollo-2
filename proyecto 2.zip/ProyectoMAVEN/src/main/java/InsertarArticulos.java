import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;


public class InsertarArticulos extends JFrame implements ActionListener{
    JPanel Insertar,eliminar,regresar;
    JButton Binsertar,Bregresar;
    private JTextField txtClaveArticulo;

    private JTextField txtNombre;
    private JTextField txtPrecio;
    private JTextField txtClaveFabricante;
    public InsertarArticulos(){
        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("INSERTAR ARTICULOS");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
/*
        regresar = new JPanel();
        regresar.setLayout(new GridLayout());
        regresar.setBounds(820, 335, 100, 60);
        regresar.setBorder(new LineBorder(Color.BLACK, 2));
        regresar.setBackground(new Color(172, 181, 189));
        this.add(regresar);

        Bregresar = new JButton("regresar");
        Bregresar.setForeground(Color.WHITE);
        Bregresar.setBackground(Color.DARK_GRAY);
        Bregresar.setBorder(new LineBorder(Color.BLACK, 4));
        Bregresar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        regresar.add(Bregresar);
        Bregresar.addActionListener(this);

*/
        JLabel lblClaveArticulo= new JLabel("Clave Articulo:");
        txtClaveArticulo= new JTextField(10);

        JLabel lblNombre= new JLabel("Nombre:");
        txtNombre= new JTextField(10);

        JLabel lblPrecio= new JLabel("Precio:");
        txtPrecio= new JTextField(10);

        JLabel lblClaveFabricante= new JLabel("Clave Fabricante:");
        txtClaveFabricante= new JTextField(10);

        Binsertar=new JButton("Insertar");
        Binsertar.addActionListener(this);


        lblClaveArticulo.setBounds(20, 20, 100, 20);
        txtClaveArticulo.setBounds(120, 20, 200, 20);
        lblNombre.setBounds(20, 50, 100, 20);
        txtNombre.setBounds(120, 50, 200, 20);
        lblPrecio.setBounds(20, 80, 100, 20);
        txtPrecio.setBounds(120, 80, 200, 20);
        lblClaveFabricante.setBounds(20, 110, 120, 20);
        txtClaveFabricante.setBounds(140, 110, 200, 20);

        Binsertar.setBounds(20, 150, 100, 30);

        this.add(lblClaveArticulo);
        this.add(txtClaveArticulo);
        this.add(lblNombre);
        this.add(txtNombre);
        this.add(lblPrecio);
        this.add(txtPrecio);
        this.add(lblClaveFabricante);
        this.add(txtClaveFabricante);
        this.add(Binsertar);

       // pack();
       // setLocationRelativeTo(null);

    }


    @Override
    public void actionPerformed(ActionEvent e) {

        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";

    if (e.getSource()==Binsertar){
        int claveArticulo =Integer.parseInt(txtClaveArticulo.getText());
        String nombre=txtNombre.getText();
        int precio=Integer.parseInt(txtPrecio.getText());
        int claveFabricante=Integer.parseInt(txtClaveFabricante.getText());

        try {
            Connection conexion= DriverManager.getConnection(url,usuario,contrasena);
            String sql="INSERT INTO articulos (clave_articulos, nombre, precio, clave_fabricante) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = conexion.prepareStatement(sql);
            preparedStatement.setInt(1,claveArticulo);
            preparedStatement.setString(2,nombre);
            preparedStatement.setInt(3,precio);
            preparedStatement.setInt(4,claveFabricante);

            int filasAfectadas = preparedStatement.executeUpdate();
            if (filasAfectadas>0){
                JOptionPane.showMessageDialog(this,"Articulo Insertado Correctamente");
            }else {
                JOptionPane.showMessageDialog(this,"No se pudo Insertar el Articulo");
            }
        }catch (SQLException ex){
            ex.printStackTrace();
        }
    }
    }
}
