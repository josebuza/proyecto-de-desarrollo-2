import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertarUsuarios extends JFrame implements ActionListener {
    JPanel Insertar,eliminar,regresar;
    JButton Binsertar,Bregresar;
    private JTextField txtNombre;
    private JTextField txtNivel;
    private JTextField txtContra;


    public InsertarUsuarios(){
        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("INSERTAR USUARIOS");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
/*
        regresar = new JPanel();
        regresar.setLayout(new GridLayout());
        regresar.setBounds(820, 335, 100, 60);
        regresar.setBorder(new LineBorder(Color.BLACK, 2));
        regresar.setBackground(new Color(172, 181, 189));
        this.add(regresar);

        Bregresar = new JButton("regresar");
        Bregresar.setForeground(Color.WHITE);
        Bregresar.setBackground(Color.DARK_GRAY);
        Bregresar.setBorder(new LineBorder(Color.BLACK, 4));
        Bregresar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        regresar.add(Bregresar);
        Bregresar.addActionListener(this);
*/
        JLabel lblNombre= new JLabel("Nombre:");
        txtNombre= new JTextField(10);

        JLabel lblNivel= new JLabel("Nivel:");
        txtNivel= new JTextField(10);

        JLabel lblContra= new JLabel("Contrasena:");
        txtContra= new JTextField(10);

        Binsertar=new JButton("Insertar");
        Binsertar.addActionListener(this);

        lblNombre.setBounds(20, 20, 100, 20);
        txtNombre.setBounds(120, 20, 200, 20);
        lblNivel.setBounds(20, 50, 100, 20);
        txtNivel.setBounds(120, 50, 200, 20);
        lblContra.setBounds(20, 80, 100, 20);
        txtContra.setBounds(120, 80, 200, 20);

        Binsertar.setBounds(20, 150, 100, 30);


        this.add(lblNombre);
        this.add(txtNombre);
        this.add(lblNivel);
        this.add(txtNivel);
        this.add(lblContra);
        this.add(txtContra);

        this.add(Binsertar);

    }



    @Override
    public void actionPerformed(ActionEvent e) {

        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";

        if (e.getSource()==Binsertar){
            String Nombre=txtNombre.getText();
            String Nivel=txtNivel.getText();
            String Contra=txtContra.getText();

            try {
                Connection conexion= DriverManager.getConnection(url,usuario,contrasena);
                String sql="INSERT INTO usuarios (Nombre, Nivel, Contra) VALUES (?, ?, ?)";
                PreparedStatement preparedStatement = conexion.prepareStatement(sql);
                preparedStatement.setString(1,Nombre);
                preparedStatement.setString(2,Nivel);
                preparedStatement.setString(3,Contra);

                int filasAfectadas = preparedStatement.executeUpdate();
                if (filasAfectadas>0){
                    JOptionPane.showMessageDialog(this,"Usuario Insertado Correctamente");
                }else {
                    JOptionPane.showMessageDialog(this,"No se pudo Insertar el Usuario");
                }
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }
    }
}
