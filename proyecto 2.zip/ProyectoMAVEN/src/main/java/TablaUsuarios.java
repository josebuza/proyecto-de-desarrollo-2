import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TablaUsuarios extends JFrame implements ActionListener {
    InsertarUsuarios insertarUsuarios;
    BorrarUsuarios borrarUsuarios;
    private JTable tabla;

    JPanel Insertar,eliminar,regresar;
    JButton Binsertar,Beliminar,Bregresar;
    public TablaUsuarios() {

        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("TABLA USUARIOS");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Nivel");
        modelo.addColumn("Contrasena");

        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";
        String consulta = "SELECT * FROM usuarios";

        try {
            Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
            Statement statement = conexion.createStatement();
            ResultSet resultSet = statement.executeQuery(consulta);

            while (resultSet.next()) {
                String Nombre = resultSet.getString("Nombre");
                String Nivel = resultSet.getString("Nivel");
                String Contrasena = resultSet.getString("Contra");

                modelo.addRow(new Object[]{Nombre,Nivel,Contrasena});
            }
            resultSet.close();
            statement.close();
            conexion.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        Container contentpane = getContentPane();
        contentpane.setLayout(null);
        tabla = new JTable(modelo);
        tabla.setBounds(50, 50, 400, 300);
        add(tabla);

        JTableHeader header = tabla.getTableHeader();
        header.setBounds(50, 20, 400, 30);
        contentpane.add(header);

        Insertar= new JPanel();
        Insertar.setLayout(new GridLayout());
        Insertar.setBounds(820, 250, 100, 60);
        Insertar.setBorder(new LineBorder(Color.BLACK,2));
        Insertar.setBackground(new Color(172,181,189));
        this.add(Insertar);

        Binsertar = new JButton("INSERTAR");
        Binsertar.setForeground(Color.WHITE);
        Binsertar.setBackground(Color.DARK_GRAY);
        Binsertar.setBorder(new LineBorder(Color.BLACK,4));
        Binsertar.setFont(new Font("Bauhaus 93",Font.BOLD,15));
        Insertar.add(Binsertar);
        Binsertar.addActionListener(this);

        insertarUsuarios=new InsertarUsuarios();
        borrarUsuarios = new BorrarUsuarios(this);

        regresar = new JPanel();
        regresar.setLayout(new GridLayout());
        regresar.setBounds(820, 335, 100, 60);
        regresar.setBorder(new LineBorder(Color.BLACK, 2));
        regresar.setBackground(new Color(172, 181, 189));
        this.add(regresar);



        Bregresar = new JButton("REGRESAR");
        Bregresar.setForeground(Color.WHITE);
        Bregresar.setBackground(Color.DARK_GRAY);
        Bregresar.setBorder(new LineBorder(Color.BLACK, 4));
        Bregresar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        regresar.add(Bregresar);
        Bregresar.addActionListener(this);

        eliminar= new JPanel();
        eliminar.setLayout(new GridLayout());
        eliminar.setBounds(820, 165, 100, 60);
        eliminar.setBorder(new LineBorder(Color.BLACK,2));
        eliminar.setBackground(new Color(172,181,189));
        this.add(eliminar);

        Beliminar = new JButton("ELIMINAR");
        Beliminar.setForeground(Color.WHITE);
        Beliminar.setBackground(Color.DARK_GRAY);
        Beliminar.setBorder(new LineBorder(Color.BLACK,4));
        Beliminar.setFont(new Font("Bauhaus 93",Font.BOLD,15));
        eliminar.add(Beliminar);
        Beliminar.addActionListener(this);

    }
    public void mostrarVentana(){
        this.setVisible(true);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Binsertar){
            insertarUsuarios.setVisible(true);
            insertarUsuarios.add(regresar);
            this.setVisible(false);
        }
        if (e.getSource()==Beliminar){
            borrarUsuarios.setVisible(true);
            borrarUsuarios.add(regresar);
            this.setVisible(false);
        }
        if (e.getSource()==Bregresar){
            insertarUsuarios.setVisible(false);
            borrarUsuarios.setVisible(false);
            this.setVisible(true);
            obtenerDatosTablaUsuarios();
        }
    }
    public void obtenerDatosTablaUsuarios(){
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);

        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";
        String consulta = "SELECT * FROM usuarios";

        try {
            Connection conexion = DriverManager.getConnection(url, usuario, contrasena);
            Statement statement = conexion.createStatement();
            ResultSet resultSet = statement.executeQuery(consulta);

            while (resultSet.next()) {
                String nombre = resultSet.getString("Nombre");
                String nivel = resultSet.getString("Nivel");
                String Contra = resultSet.getString("Contra");

                modelo.addRow(new Object[]{nombre,nivel, Contra});
            }
            resultSet.close();
            statement.close();
            conexion.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
