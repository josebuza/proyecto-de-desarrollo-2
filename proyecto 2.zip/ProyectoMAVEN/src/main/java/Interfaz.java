import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Interfaz extends JFrame implements ActionListener {
    private LOGIN login;

    JPanel regresar;
    JButton Bregresar;

    public VenAdmin VentanaAdmin;
    public MenuAdmin menuAdmin;
    public MenuGerente menuGerente;
    public MenuEmpleado menuEmpleado;

    private JPanel Inicio;
    private JPanel P_Usuario;
    private JPanel P_Contraseña;
    private JPanel ACC;

    private JLabel InicioSesion;
    private JLabel Usuario;
    private JLabel Contraseña;

    private JButton Acceder;

    private JTextField usua;

    private JPasswordField Contra;

    private Choice tipo;

    private ventanadelmenu ventanaMenu;

    public Interfaz() {
        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("Abarrotes doña coyo");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        // INICIO
        Inicio = new JPanel();
        Inicio.setBounds(205, 25, 550, 75);
        Inicio.setBackground(new Color(173, 181, 189));
        this.add(Inicio);

        // Titulo
        InicioSesion = new JLabel("ABARROTES DOÑA COYO");
        InicioSesion.setFont(new Font("Bauhaus 93", Font.BOLD, 45));
        Inicio.add(InicioSesion);
        Inicio.setVisible(true);

        // Espacio de usuario
        P_Usuario = new JPanel();
        P_Usuario.setBounds(130, 120, 150, 42);
        P_Usuario.setBackground(new Color(172, 181, 189));
        this.add(P_Usuario);

        Usuario = new JLabel("Usuario :");
        Usuario.setFont(new Font("Bauhaus 93", Font.BOLD, 25));
        P_Usuario.add(Usuario);
        P_Usuario.setVisible(true);

        usua = new JTextField();
        usua.setFont(new Font("Bauhaus 93", Font.BOLD, 25));
        usua.setBounds(350, 120, 300, 42);
        usua.setBorder(new LineBorder(Color.BLACK, 2));
        usua.setBackground(new Color(172, 181, 189));
        this.add(usua);
        this.add(Inicio);

        // Espacio para contraseña
        P_Contraseña = new JPanel();
        P_Contraseña.setBounds(130, 200, 150, 42);
        P_Contraseña.setBackground(new Color(172, 181, 189));
        this.add(P_Contraseña);

        Contraseña = new JLabel("Contraseña :");
        Contraseña.setFont(new Font("Bauhaus 93", Font.BOLD, 25));
        P_Contraseña.add(Contraseña);
        P_Contraseña.setVisible(true);

        Contra = new JPasswordField();
        Contra.setFont(new Font("Bauhaus 93", Font.BOLD, 25));
        Contra.setBounds(350, 200, 300, 42);
        Contra.setBorder(new LineBorder(Color.BLACK, 2));
        Contra.setBackground(new Color(172, 181, 189));
        this.add(Contra);
        this.add(Inicio);

        // Panel de botones
        ACC = new JPanel();
        ACC.setLayout(new GridLayout());
        ACC.setBounds(415, 270, 150, 100);
        ACC.setBorder(new LineBorder(Color.BLACK, 2));
        ACC.setBackground(new Color(172, 181, 189));
        this.add(ACC);

        Acceder = new JButton("Acceder");
        Acceder.setForeground(Color.WHITE);
        Acceder.setBackground(Color.DARK_GRAY);
        Acceder.setBorder(new LineBorder(Color.BLACK, 4));
        Acceder.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        ACC.add(Acceder);
        Acceder.addActionListener(this);

        menuGerente = new MenuGerente();
        menuAdmin = new MenuAdmin();
        menuEmpleado = new MenuEmpleado();
        ventanaMenu = new ventanadelmenu();
        login = new LOGIN(this);
    }

    public String getusua() {
        String usuarioLI = usua.getText();
        return usuarioLI;
    }

    public String getpass() {
        char[] passwordChars = Contra.getPassword();
        String password = new String(passwordChars);
        return password;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Acceder) {
            login.IC();
            // Ocultar ventana inicio
            String Nivel_seguridad = login.getNivelSeguridad();
            if (Nivel_seguridad!=null){

                if (Nivel_seguridad.equals("Admin")) {
                    menuAdmin.MenuAdmin();
                    menuAdmin.setVisible(true);

                } else if (Nivel_seguridad.equals("Gerente")) {
                    menuGerente.MenuGerente();
                    menuGerente.setVisible(true);

                } else if (Nivel_seguridad.equals("Empleado")) {
                    menuEmpleado.MenuEmpleado();
                    menuEmpleado.setVisible(true);

                }

            }

            this.setVisible(false);

        }
    }
}

