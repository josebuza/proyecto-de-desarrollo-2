import javax.swing.*;
import java.sql.*;

public class LOGIN {

    private ventanamenu ventanadelmenu;
    private Interfaz interfaz;
    private String nivelSeguridad; // Variable de nivel de seguridad

    public LOGIN(Interfaz interfaz) {
        this.interfaz = interfaz;
    }

    public void IC() {
        String url = "jdbc:mysql://localhost:3306/tienda";
        String username = "root";
        String password = "12345";

        String Contrasena = interfaz.getpass();
        String user = interfaz.getusua();

        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            String query = "SELECT * FROM usuarios WHERE Nombre = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, user);
            ResultSet rs = statement.executeQuery();

            // Comparar contraseñas y abrir el menú correspondiente
            if (rs.next()) {
                String guardarContra = rs.getString("Contra");
                if (guardarContra.equals(Contrasena)) {
                    // Comparar nivel de seguridad
                    String nivel = rs.getString("Nivel");
                    if (nivel.equals("1")) {
                        nivelSeguridad = "Admin";
                    } else if (nivel.equals("2")) {
                        nivelSeguridad = "Gerente";
                    } else if (nivel.equals("3")) {
                        nivelSeguridad = "Empleado";
                    }
                    else {
                        nivelSeguridad=null;
                        JOptionPane.showMessageDialog(null,"Nivel de Seguridad Desconocido");
                    }
                } else {
                    JOptionPane.showMessageDialog(null,"Usuario o Contraseña incorrecta");
                    interfaz.setVisible(true);
                    ventanadelmenu.setVisible(false);
                }
            }

            // Cerrar conexiones
            statement.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public String getNivelSeguridad() {
        return nivelSeguridad;
    }
}