import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertarVentas extends JFrame implements ActionListener {
    JPanel Insertar,eliminar,regresar;
    JButton Binsertar,Bregresar;
    private JTextField txtProducto;
    private JTextField txtVendidos;
    private JTextField txtDevueltos;


    public InsertarVentas(){
        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("INSERTAR Ventas");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        regresar = new JPanel();
        regresar.setLayout(new GridLayout());
        regresar.setBounds(820, 335, 100, 60);
        regresar.setBorder(new LineBorder(Color.BLACK, 2));
        regresar.setBackground(new Color(172, 181, 189));
        this.add(regresar);

        Bregresar = new JButton("regresar");
        Bregresar.setForeground(Color.WHITE);
        Bregresar.setBackground(Color.DARK_GRAY);
        Bregresar.setBorder(new LineBorder(Color.BLACK, 4));
        Bregresar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        regresar.add(Bregresar);
        Bregresar.addActionListener(this);

        JLabel lblProducto= new JLabel("Producto:");
        txtProducto= new JTextField(10);
        JLabel lblVendidos= new JLabel("Vendidos:");
        txtVendidos= new JTextField(10);
        JLabel lblDevueltos= new JLabel("Devueltos:");
        txtDevueltos= new JTextField(10);

        Binsertar=new JButton("Insertar");
        Binsertar.addActionListener(this);

        lblProducto.setBounds(20, 20, 100, 20);
        txtProducto.setBounds(120, 20, 200, 20);
        lblVendidos.setBounds(20, 50, 100, 20);
        txtVendidos.setBounds(120, 50, 200, 20);
        lblDevueltos.setBounds(20, 80, 100, 20);
        txtDevueltos.setBounds(120, 80, 200, 20);

        Binsertar.setBounds(20, 150, 100, 30);


        this.add(lblProducto);
        this.add(txtProducto);
        this.add(lblVendidos);
        this.add(txtVendidos);
        this.add(lblDevueltos);
        this.add(txtDevueltos);

        this.add(Binsertar);

    }



    @Override
    public void actionPerformed(ActionEvent e) {

        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";

        if (e.getSource()==Binsertar){
            String Producto=txtProducto.getText();
            int Vendidos=Integer.parseInt(txtVendidos.getText());
            int Devueltos=Integer.parseInt(txtDevueltos.getText());

            try {
                Connection conexion= DriverManager.getConnection(url,usuario,contrasena);
                String sql="INSERT INTO ventas (Producto, Vendidos, Devueltos) VALUES (?, ?, ?)";
                PreparedStatement preparedStatement = conexion.prepareStatement(sql);
                preparedStatement.setString(1,Producto);
                preparedStatement.setInt(2,Vendidos);
                preparedStatement.setInt(3,Devueltos);

                int filasAfectadas = preparedStatement.executeUpdate();
                if (filasAfectadas>0){
                    JOptionPane.showMessageDialog(this,"Articulo Insertado Correctamente");
                }else {
                    JOptionPane.showMessageDialog(this,"No se pudo Insertar el Articulo");
                }
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }
    }
}
