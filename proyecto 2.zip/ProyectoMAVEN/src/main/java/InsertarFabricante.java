import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertarFabricante extends JFrame implements ActionListener {
    JPanel Insertar,eliminar,regresar;
    JButton Binsertar,Bregresar;

    TablaFabricantes tablaFabricantes;
    private JTextField txtClaveFabricante;
    private JTextField txtNombre;


    public InsertarFabricante(){
        this.setLayout(null);
        this.setBounds(450, 50, 950, 450);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("INSERTAR Fabricantes");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
/*
        regresar = new JPanel();
        regresar.setLayout(new GridLayout());
        regresar.setBounds(820, 335, 100, 60);
        regresar.setBorder(new LineBorder(Color.BLACK, 2));
        regresar.setBackground(new Color(172, 181, 189));
        this.add(regresar);

        Bregresar = new JButton("regresar");
        Bregresar.setForeground(Color.WHITE);
        Bregresar.setBackground(Color.DARK_GRAY);
        Bregresar.setBorder(new LineBorder(Color.BLACK, 4));
        Bregresar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        regresar.add(Bregresar);
        Bregresar.addActionListener(this);
*/


        JLabel lblClaveFabricante= new JLabel("Clave Fabricante:");
        txtClaveFabricante= new JTextField(10);

        JLabel lblNombre= new JLabel("Nombre:");
        txtNombre= new JTextField(10);

        Binsertar=new JButton("Insertar");
        Binsertar.addActionListener(this);

        lblClaveFabricante.setBounds(20, 50, 120, 20);
        txtClaveFabricante.setBounds(140, 50, 200, 20);
        lblNombre.setBounds(20, 110, 100, 20);
        txtNombre.setBounds(120, 110, 200, 20);

        Binsertar.setBounds(20, 150, 100, 30);



        this.add(lblNombre);
        this.add(txtNombre);


        this.add(lblClaveFabricante);
        this.add(txtClaveFabricante);

        this.add(Binsertar);

    }



    @Override
    public void actionPerformed(ActionEvent e) {

        String url = "jdbc:mysql://localhost:3306/tienda";
        String usuario = "root";
        String contrasena = "12345";

        if (e.getSource()==Binsertar){
            int claveFabricante=Integer.parseInt(txtClaveFabricante.getText());
            String nombre=txtNombre.getText();

            try {
                Connection conexion= DriverManager.getConnection(url,usuario,contrasena);
                String sql="INSERT INTO fabricantes (clave_fabricante, nombre) VALUES (?, ?)";
                PreparedStatement preparedStatement = conexion.prepareStatement(sql);
                preparedStatement.setInt(1,claveFabricante);
                preparedStatement.setString(2,nombre);



                int filasAfectadas = preparedStatement.executeUpdate();
                if (filasAfectadas>0){
                    JOptionPane.showMessageDialog(this,"Articulo Insertado Correctamente");
                }else {
                    JOptionPane.showMessageDialog(this,"No se pudo Insertar el Articulo");
                }
            }catch (SQLException ex){
                ex.printStackTrace();
            }
        }
        if (e.getSource() == Bregresar){
            this.isVisible();
            tablaFabricantes.setVisible(true);
        }
    }
}
