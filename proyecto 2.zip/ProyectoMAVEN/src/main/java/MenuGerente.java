import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuGerente extends JFrame implements ActionListener {

    TablaArticulos tablaArticulos;

    TablaVentas tablaVentas;
    TablaStock tablaStock;
    TablaFabricantes tablaFabricantes;
    JPanel stock,fabricantes,articulo,ventas,regresar;
    JButton Bstock,Bfabricantes,Barticulos,Bregresar,Bventas;
    public  void MenuGerente(){
        JOptionPane.showMessageDialog(null,"Bienvenido Gerente");
        this.setLayout(null);
        this.setBounds(450,50,650,710);
        this.getContentPane().setBackground(new Color(173, 181, 189));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Titulo del programa
        this.setTitle("Menu Empleado");
        this.setFont(new Font("Bauhaus 93", Font.BOLD, 10));
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        articulo = new JPanel();
        articulo.setLayout(new GridLayout());
        articulo.setBounds(155,50,350,100);
        articulo.setBorder(new LineBorder(Color.BLACK,2));
        articulo.setBackground(new Color(172,181,189));
        this.add(articulo);

        Barticulos = new JButton("ARTICULOS");
        Barticulos.setForeground(Color.WHITE);
        Barticulos.setBackground(Color.DARK_GRAY);
        Barticulos.setBorder(new LineBorder(Color.BLACK,4));
        Barticulos.setFont(new Font("Bauhaus 93",Font.BOLD,20));
        articulo.add(Barticulos);
        Barticulos.addActionListener(this);

        fabricantes = new JPanel();
        fabricantes.setLayout(new GridLayout());
        fabricantes.setBounds(155,200,350,100);
        fabricantes.setBorder(new LineBorder(Color.BLACK,2));
        fabricantes.setBackground(new Color(172,181,189));
        this.add(fabricantes);

        Bfabricantes = new JButton("FABRICANTES");
        Bfabricantes.setForeground(Color.WHITE);
        Bfabricantes.setBackground(Color.DARK_GRAY);
        Bfabricantes.setBorder(new LineBorder(Color.BLACK,4));
        Bfabricantes.setFont(new Font("Bauhaus 93",Font.BOLD,20));
        fabricantes.add(Bfabricantes);
        Bfabricantes.addActionListener(this);

        stock = new JPanel();
        stock.setLayout(new GridLayout());
        stock.setBounds(155,350,350,100);
        stock.setBorder(new LineBorder(Color.BLACK,2));
        stock.setBackground(new Color(172,181,189));
        this.add(stock);

        Bstock = new JButton("STOCK");
        Bstock.setForeground(Color.WHITE);
        Bstock.setBackground(Color.DARK_GRAY);
        Bstock.setBorder(new LineBorder(Color.BLACK,4));
        Bstock.setFont(new Font("Bauhaus 93",Font.BOLD,20));
        stock.add(Bstock);
        Bstock.addActionListener(this);

        regresar = new JPanel();
        regresar.setLayout(new GridLayout());
        regresar.setBounds(820, 335, 100, 60);
        regresar.setBorder(new LineBorder(Color.BLACK, 2));
        regresar.setBackground(new Color(172, 181, 189));
        this.add(regresar);

        Bregresar = new JButton("regresar");
        Bregresar.setForeground(Color.WHITE);
        Bregresar.setBackground(Color.DARK_GRAY);
        Bregresar.setBorder(new LineBorder(Color.BLACK, 4));
        Bregresar.setFont(new Font("Bauhaus 93", Font.BOLD, 15));
        regresar.add(Bregresar);
        Bregresar.addActionListener(this);

        ventas = new JPanel();
        ventas.setLayout(new GridLayout());
        ventas.setBounds(155,500,350,100);
        ventas.setBorder(new LineBorder(Color.BLACK,2));
        ventas.setBackground(new Color(172,181,189));
        this.add(ventas);

        Bventas = new JButton("VENTAS");
        Bventas.setForeground(Color.WHITE);
        Bventas.setBackground(Color.DARK_GRAY);
        Bventas.setBorder(new LineBorder(Color.BLACK,4));
        Bventas.setFont(new Font("Bauhaus 93",Font.BOLD,20));
        ventas.add(Bventas);
        Bventas.addActionListener(this);

        tablaArticulos = new TablaArticulos();
        tablaStock = new TablaStock();
        tablaFabricantes =new TablaFabricantes();
        tablaVentas = new TablaVentas();


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Barticulos){
            tablaArticulos.setVisible(true);
            this.setVisible(false);
            tablaArticulos.add(regresar);
        }
        if (e.getSource() == Bfabricantes){
            tablaFabricantes.setVisible(true);
            this.setVisible(false);
            tablaFabricantes.add(regresar);
        }
        if (e.getSource() == Bstock){
            tablaStock.setVisible(true);
            this.setVisible(false);
            tablaStock.add(regresar);

        }
        if (e.getSource() == Bventas){
            tablaVentas.setVisible(true);
            this.setVisible(false);
            tablaVentas.add(regresar);
        }
        if (e.getSource() == Bregresar){
            if (tablaVentas.isVisible()){
                tablaVentas.setVisible(false);

            }
            if (tablaStock.isVisible()){
                tablaStock.setVisible(false);
            }
            if (tablaArticulos.isVisible()){
                tablaArticulos.setVisible(false);

            }
            if (tablaFabricantes.isVisible()){
                tablaFabricantes.setVisible(false);
            }
            this.setVisible(true);
        }

    }

}


